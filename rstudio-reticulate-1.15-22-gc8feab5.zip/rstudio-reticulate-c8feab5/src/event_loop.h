
#ifndef __PYTHON_EVENT_LOOP__
#define __PYTHON_EVENT_LOOP__

namespace event_loop {

void initialize();

} // namespace event_loop

#endif // __PYTHON_EVENT_LOOP__

